ProGameFinds site generator (for developers only)

build.py: builds every page (homepage, subpages and guides) from the content data.
          It needs the content folder, which is not included in this package.
make_index.py: builds only the homepage and the theme files, using the data inside build.py.

Requirements: Python 3 and Pillow (pip install pillow).
Before running, change the SRC and OUT paths at the top of build.py and make_index.py
(and the sys.path line in make_index.py) to your own folders.

The generated homepage matches site/index.html in this package.
