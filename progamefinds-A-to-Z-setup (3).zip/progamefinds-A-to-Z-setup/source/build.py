#!/usr/bin/env python3
"""Builds the ProGameFinds website from /home/claude/site-src into /home/claude/site."""
import html
import os
import re
import shutil

from PIL import Image

SRC = '/home/claude/site-src'
OUT = '/home/claude/site'
SITE = 'https://progamefinds.online'
AFF = 'progamefinds-20'
LOGO = 'assets/logos/logo-primary-stacked.png'
DESC_HOME = ('Explore gaming mice, headsets, keyboards, controllers and setup ideas with practical buying guides '
             'that put fit, compatibility and informed choices first.')

NAV = [
    ('index.html#categories', 'Gaming gear', 'gear'),
    ('index.html#guides', 'Buying guides', 'guides'),
    ('index.html#faq', 'Questions', 'faq'),
    ('about.html', 'About', 'about'),
    ('index.html#contact', 'Contact', 'contact'),
]

FILTERS = [('all', 'All gear'), ('mice', 'Mice'), ('headsets', 'Headsets'), ('keyboards', 'Keyboards'),
           ('controllers', 'Controllers'), ('room', 'Room & setup'), ('chairs', 'Chairs & desks')]

# (gid, category, title, description, product art, art alt text, items: (label, title, description, ASIN))
PRODUCT_GROUPS = [
    ('mice', 'mice', 'Mice', 'Wireless and wired gaming mice.', 'mouse.svg',
     'Illustrative mouse artwork, not a photograph of the exact product', [
         ('Pick 01.1', 'Logitech G305 LIGHTSPEED', 'Wireless gaming mouse.', 'B07CMS5Q6P'),
         ('Pick 01.2', 'Logitech G502 HERO', 'Wired gaming mouse with programmable buttons and RGB lighting.', 'B07GBZ4Q68'),
         ('Alternative', 'Logitech G502 X Plus Wireless', 'Wireless version of the G502 family.', 'B092CB69Q4'),
         ('Alternative', 'Logitech G502 Lightspeed (HERO 25K)', 'Wireless G502 with HERO 25K sensor.', 'B07L4BM851'),
     ]),
    ('headsets', 'headsets', 'Headsets', 'Wired headsets for PC and console.', 'headset.svg',
     'Illustrative headset artwork, not a photograph of the exact product', [
         ('Pick 02.1', 'HyperX Cloud III', 'Wired gaming headset with DTS Spatial Audio for PC, PS5 and Xbox.', 'B0C3BSZ56D'),
         ('Pick 02.2', 'Razer BlackShark V2 X', 'Wired gaming headset.', 'B086PKMZ21'),
         ('Alternative', 'HyperX Cloud III S Wireless', 'Wireless version of the Cloud III.', 'B0F6NZWPTC'),
         ('Alternative', 'HyperX Cloud II', 'Earlier model in the same family.', 'B00SAYCXWG'),
         ('Alternative', 'HyperX Cloud III (second listing)', 'Same headset on a separate listing. Check the color on Amazon.', 'B0C3BV19Q3'),
     ]),
    ('keyboards', 'keyboards', 'Keyboards', 'Full-size and tenkeyless gaming keyboards.', 'keyboard.svg',
     'Illustrative keyboard artwork, not a photograph of the exact product', [
         ('Pick 03.1', 'Logitech G213 Prodigy', 'Wired gaming keyboard with LIGHTSYNC RGB backlit keys.', 'B07QGHK6Q8'),
         ('Pick 03.2', 'SteelSeries Apex 3 TKL RGB', 'Tenkeyless gaming keyboard with 8-zone RGB.', 'B09FTNMT84'),
     ]),
    ('controllers', 'controllers', 'Controllers', 'Wired controllers for Xbox and PC.', 'controller.svg',
     'Illustrative controller artwork, not a photograph of the exact product', [
         ('Pick 04.1', 'GameSir G7 Pro', 'Wired controller for Xbox Series X|S and PC.', 'B0FD41XC3P'),
         ('Pick 04.2', 'GameSir G7 SE', 'Wired controller with Hall Effect sticks for Xbox and PC.', 'B0C7GW9F88'),
         ('Alternative', 'GameSir G7 SE (licensed edition)', 'Officially licensed edition with Hall Effect sticks.', 'B0CT3BXRLS'),
         ('Alternative', 'GameSir Nova Lite 2 Wireless', 'Wireless PC controller with Hall Effect joysticks and triggers.', 'B0F3D25PD3'),
     ]),
    ('setup', 'room', 'Setup and room', 'Desk and room upgrades.', 'lighting.svg',
     'Illustrative lighting artwork, not a photograph of the exact product', [
         ('Pick 05.1', 'Govee RGBIC LED Strip', 'Smart RGBIC LED strip with Bluetooth app control.', 'B0991Q94KP'),
         ('Pick 05.2', 'KSIPZE 100ft RGB Strip', '100 ft RGB LED strip with music sync.', 'B09V366BDY'),
         ('Alternative', 'DAYBETTER LED Strip 32.8 ft', 'Color-changing kit with remote and power supply.', 'B08D99TWQJ'),
         ('Alternative', 'HBOWMDJIA LED Lights 200 ft', 'Two 100 ft rolls with remote and app control.', 'B0DFYBYPZM'),
         ('Alternative', 'Leeleberd LED Lights 100 ft', 'Music-sync RGB lights in two 50 ft rolls.', 'B0C2MHG632'),
     ]),
]

# (title, description, Amazon search URL, aria label)
CHAIR_SEARCH = [
    ('Gaming chairs', 'Amazon search results for gaming chairs, with our affiliate tag.',
     'https://www.amazon.com/s?k=gaming+chair&tag=progamefinds-20',
     'Search on Amazon for Gaming chairs, opens in a new tab (paid link)'),
    ('Gaming desks', 'Amazon search results for gaming desks, with our affiliate tag.',
     'https://www.amazon.com/s?k=gaming+desk&tag=progamefinds-20',
     'Search on Amazon for Gaming desks, opens in a new tab (paid link)'),
]

GUIDES = [
    ('choosing-a-gaming-mouse', 'How to choose a gaming mouse', 'Grip, shape, weight, sensor claims and connection trade-offs.'),
    ('gaming-keyboard-layouts-and-switches', 'Gaming keyboard layouts and switches', 'Compare layout, switch feel, noise, and desk space.'),
    ('choosing-a-gaming-headset', 'How to choose a gaming headset', 'Comfort, microphone, connection and platform compatibility.'),
    ('controller-compatibility-checklist', 'Controller compatibility checklist', 'Check platform support, connection, controls and return terms.'),
    ('gaming-desk-sizing-guide', 'Gaming desk sizing guide', 'Measure your room, monitor depth, chair clearance and cable paths.'),
    ('gaming-chair-fit-and-ergonomics', 'Gaming chair fit and ergonomics', 'Prioritize fit and adjustability over marketing labels.'),
    ('gaming-room-lighting', 'Gaming room lighting guide', 'Plan ambient lighting without distracting glare.'),
    ('building-a-balanced-gaming-setup', 'Build a balanced gaming setup', 'Allocate budget by comfort, performance and actual needs.'),
    ('wired-vs-wireless-gaming-gear', 'Wired vs wireless gaming gear', 'Understand battery, cable, latency and convenience trade-offs.'),
    ('how-to-check-an-online-product-listing', 'How to evaluate a product listing', 'Verify model numbers, seller, compatibility, warranty and reviews.'),
]

STEPS = [
    ('01', 'Choose with clarity', 'Understand the features that actually affect your setup.'),
    ('02', 'Check compatibility', 'Confirm platform, connections and exact model revisions.'),
    ('03', 'Shop with context', 'Verify seller, warranty and current listing details before buying.'),
]

FAQ = [
    ('Do I pay more when I use these links?',
     'No. The price on Amazon is the same whether you use one of our links or not. ProGameFinds may earn a commission on qualifying purchases.'),
    ('Does ProGameFinds sell these products?',
     "No. Every purchase happens on Amazon, under Amazon's checkout and policies. We do not handle payments or shipping."),
    ('How are the picks chosen?',
     'We organize these picks by gaming-gear category and include alternatives. This page does not document hands-on testing or a repeatable comparison methodology, and we do not claim access to Amazon keyword-click or conversion data. Check current product details with the manufacturer and on Amazon before buying.'),
    ('How can I reach you?',
     'The contact form is currently inactive, so no message can be submitted or delivered yet. We will publish a verified contact channel after the owner completes and tests its setup.'),
]

POLICIES = [
    ('Affiliate disclosure',
     'Amazon Associates application status must be confirmed by the site owner. The current project records the application as pending; this website must not be described as approved until Amazon confirms acceptance. <a href="affiliate-disclosure.html">Read the full affiliate disclosure</a>.',
     'As an Amazon Associate I earn from qualifying purchases.'),
    ('Privacy',
     'This version uses locally hosted site assets and does not intentionally set analytics or advertising cookies. The contact form is disabled and no visitor message is transmitted. Hosting providers may process technical request data to deliver and secure the site. <a href="privacy.html">Read the full privacy policy</a>.',
     None),
    ('Prices and availability',
     'This version does not display live prices, ratings or stock levels. Seller, price, availability, model revision and warranty can change; verify the exact current listing and manufacturer information before buying.',
     None),
    ('Terms of use',
     'ProGameFinds provides general informational content and is not a retailer. Product names and trademarks belong to their owners; no brand endorsement is implied. <a href="terms.html">Read the full terms of use</a>.',
     None),
]

LOGO_OPTIONS = [
    ('logo-primary-stacked.png', 'Primary logo', 'Stacked crown lockup with the ProGameFinds wordmark. Used in the site header and footer.', True),
    ('logo-full-with-controller.png', 'Full logo', 'Crown, PGF letters, controller and the Discover • Play • Save tagline.', False),
    ('logo-horizontal-banner.png', 'Horizontal logo', 'Wide banner lockup for headers, banners and wide placements.', False),
    ('logo-wordmark.png', 'Wordmark', 'ProGameFinds text-only logo for tight spaces.', False),
    ('icon-app-rounded.png', 'App icon', 'Rounded neon PGF square. Used as the favicon and app icon.', False),
    ('icon-round-cyan.png', 'Round badge · cyan ring', 'Circular badge with a cyan neon ring for avatars and profile pictures.', False),
    ('icon-crest.png', 'Crest badge', 'Shield-style crest with a chevron base.', False),
    ('icon-round-violet.png', 'Round badge · violet ring', 'Circular badge with a violet neon ring for avatars and profile pictures.', False),
]

SWATCHES = [
    ('Midnight', '#000007', 'Page background'),
    ('Deep navy', '#00103B', 'Panels and cards'),
    ('Royal blue', '#00287C', 'Deep accents'),
    ('Indigo', '#412B9B', 'Gradient mid-tone'),
    ('Neon violet', '#8A3FFC', 'Buttons and highlights'),
    ('Neon cyan', '#46D7FF', 'Links and accents'),
    ('Steel silver', '#758EBD', 'Secondary text and lines'),
    ('Ice silver', '#C7E2ED', 'Headings and light text'),
]

README = """ProGameFinds website - new logo and colour theme

Upload or replace these files in your site repository:
- index.html, about.html, affiliate-disclosure.html, privacy.html, terms.html
- guides/ (all 10 guide pages)
- assets/ (styles.css, app.js, logos, icons, product images, social preview, hero artwork)
- favicon.ico and apple-touch-icon.png

Do not delete files that are not listed here (for example CNAME, sitemap.xml or robots.txt)
unless you know you need to.

Affiliate links, the tracking ID (progamefinds-20) and the disclosure text are unchanged.
Open index.html in a browser to preview locally, or push to your preview branch.
"""


def esc(s):
    return html.escape(s, quote=True)


def size_attr(rel_path):
    p = os.path.join(SRC, rel_path)
    if not os.path.exists(p):
        return ''
    w, h = Image.open(p).size
    return f' width="{w}" height="{h}"'


def plain(text):
    t = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text).replace('**', '').replace('`', '')
    return re.sub(r'\s+', ' ', t).strip()


LINK = re.compile(r'\[([^\]]+)\]\(([^)\s]+)\)')


def fmt(t):
    t = html.escape(t, quote=False)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', t)
    return re.sub(r'`([^`]+)`', r'<code>\1</code>', t)


def link(text, url, rel):
    if url.startswith(SITE):
        url = rel + url[len(SITE):].lstrip('/')
    attrs = ''
    if url.startswith('http'):
        attrs = ' target="_blank" rel="sponsored noopener"' if 'amazon.' in url else ' target="_blank" rel="noopener"'
    return f'<a href="{html.escape(url, quote=True)}"{attrs}>{fmt(text)}</a>'


def inline(s, rel):
    out, pos = [], 0
    for m in LINK.finditer(s):
        out.append(fmt(s[pos:m.start()]))
        out.append(link(m.group(1), m.group(2), rel))
        pos = m.end()
    out.append(fmt(s[pos:]))
    return ''.join(out)


def md(text, rel):
    out, para, items = [], [], []
    kind = None

    def flush_para():
        if para:
            out.append('<p>' + inline(' '.join(para), rel) + '</p>')
            para.clear()

    def flush_list():
        if items:
            out.append('<' + kind + '>' + ''.join('<li>' + inline(i, rel) + '</li>' for i in items) + '</' + kind + '>')
            items.clear()

    for raw in text.split('\n'):
        line = raw.strip()
        if not line:
            flush_para()
            flush_list()
            continue
        heading = re.match(r'^(#{2,4})\s+(.*)$', line)
        if heading:
            flush_para()
            flush_list()
            level = len(heading.group(1))
            out.append('<h%d>%s</h%d>' % (level, inline(heading.group(2), rel), level))
            continue
        bullet = re.match(r'^[-*]\s+(.*)$', line)
        number = re.match(r'^\d+[.)]\s+(.*)$', line)
        if bullet or number:
            flush_para()
            wanted = 'ul' if bullet else 'ol'
            if kind != wanted:
                flush_list()
                kind = wanted
            items.append((bullet or number).group(1))
            continue
        flush_list()
        para.append(line)
    flush_para()
    flush_list()
    return '\n'.join(out)


def header(rel, active):
    links = ''
    for href, label, key in NAV:
        cur = ' aria-current="page"' if key == active else ''
        links += f'<a href="{rel}{href}"{cur}>{label}</a>'
    return f'''<a class="skip" href="#main">Skip to content</a>
<header class="site-header">
  <div class="wrap nav-wrap">
    <a class="brand" href="{rel}index.html" aria-label="ProGameFinds home"><span class="logo-tile"><img src="{rel}{LOGO}" alt="ProGameFinds logo"{size_attr(LOGO)}></span></a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav" aria-label="Open menu"><span></span><span></span><span></span></button>
    <nav class="site-nav" id="site-nav" aria-label="Main navigation">
      {links}
      <a class="btn btn-primary btn-sm" href="{rel}index.html#categories">Browse gear</a>
    </nav>
  </div>
</header>'''


def footer(rel):
    return f'''<footer class="site-footer">
  <div class="wrap footer-grid">
    <div class="footer-brand">
      <span class="logo-tile"><img src="{rel}{LOGO}" alt="ProGameFinds logo"{size_attr(LOGO)}></span>
      <p>Discover • Play • Save</p>
      <p>Follow us @ProGameFinds</p>
    </div>
    <div>
      <h4>Explore</h4>
      <ul>
        <li><a href="{rel}index.html#categories">Gaming gear</a></li>
        <li><a href="{rel}index.html#chairs">Chairs and desks</a></li>
        <li><a href="{rel}index.html#guides">Buying guides</a></li>
        <li><a href="{rel}index.html#logo">Logo and brand</a></li>
      </ul>
    </div>
    <div>
      <h4>Information</h4>
      <ul>
        <li><a href="{rel}about.html">About</a></li>
        <li><a href="{rel}index.html#faq">Questions</a></li>
        <li><a href="{rel}index.html#contact">Contact</a></li>
      </ul>
    </div>
    <div>
      <h4>Policies</h4>
      <ul>
        <li><a href="{rel}affiliate-disclosure.html">Affiliate disclosure</a></li>
        <li><a href="{rel}privacy.html">Privacy</a></li>
        <li><a href="{rel}terms.html">Terms</a></li>
        <li><a href="{rel}index.html#policies">Site notes</a></li>
      </ul>
    </div>
  </div>
  <div class="wrap footer-bottom">
    <div>
      <p><strong>Amazon Associates application pending — ProGameFinds is not yet approved.</strong></p>
      <p>As an Amazon Associate I earn from qualifying purchases.</p>
      <p>Prices change. Check Amazon before you buy.</p>
    </div>
    <div>
      <p>© 2026 ProGameFinds</p>
      <p><a href="#top">Back to top</a></p>
    </div>
  </div>
</footer>'''


def page(title, desc, path, body, active=''):
    rel = '../' if path.startswith('guides/') else ''
    url = f'{SITE}/{path}'
    img = f'{SITE}/assets/social-preview.jpg'
    head = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{esc(title)}</title>
<meta name="description" content="{esc(desc)}">
<link rel="canonical" href="{url}">
<meta name="robots" content="index,follow,max-image-preview:large">
<meta name="theme-color" content="#03050F">
<meta name="color-scheme" content="dark">
<meta property="og:site_name" content="ProGameFinds">
<meta property="og:type" content="website">
<meta property="og:title" content="{esc(title)}">
<meta property="og:description" content="{esc(desc)}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{img}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{esc(title)}">
<meta name="twitter:description" content="{esc(desc)}">
<meta name="twitter:image" content="{img}">
<link rel="icon" href="{rel}favicon.ico" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="{rel}assets/icons/favicon-32.png">
<link rel="apple-touch-icon" href="{rel}apple-touch-icon.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Exo+2:wght@600;700;800&amp;family=Inter:wght@400;500;600&amp;display=swap">
<link rel="stylesheet" href="{rel}assets/progamefinds-theme.css">
</head>
<body id="top">'''
    return (head + '\n' + header(rel, active) + '\n<main id="main">\n' + body + '\n</main>\n'
            + footer(rel) + '\n<script src="' + rel + 'assets/progamefinds-app.js" defer></script>\n</body>\n</html>\n')


def product_card(cat, label, title, desc, url, art, alt, asin=None, button='View on Amazon', aria=None):
    pick = 'pick alt' if label == 'Alternative' else 'pick'
    asin_html = f'<p class="asin">ASIN <strong>{asin}</strong></p>' if asin else ''
    aria = aria or f'View on Amazon for {title}, opens in a new tab (paid link)'
    search = esc(f'{title} {desc}')
    return f'''<article class="product" data-cat="{cat}" data-search="{search}">
  <div class="product-art"><img src="assets/products/{art}" alt="{esc(alt)}" loading="lazy"></div>
  <div class="product-body">
    <span class="{pick}">{esc(label)}</span>
    <h4>{esc(title)}</h4>
    <p>{esc(desc)}</p>
    {asin_html}
    <a class="btn btn-buy" href="{esc(url)}" target="_blank" rel="sponsored noopener" aria-label="{esc(aria)}">{button}</a>
    <p class="fine">Paid link · opens in a new tab</p>
  </div>
</article>'''


def group_html(gid, title, desc, cards):
    return f'''<section class="group" id="{gid}">
  <div class="group-head"><h3>{esc(title)}</h3><p>{esc(desc)}</p></div>
  <div class="grid">
{cards}
  </div>
</section>'''


def groups_html():
    out = []
    for gid, cat, title, desc, art, alt, items in PRODUCT_GROUPS:
        cards = '\n'.join(
            product_card(cat, label, t, d, f'https://www.amazon.com/dp/{a}?tag={AFF}', art, alt, asin=a)
            for label, t, d, a in items)
        out.append(group_html(gid, title, desc, cards))
    chair_cards = '\n'.join(
        product_card('chairs', 'Category search', t, d, url, 'chair.svg',
                     'Illustrative chair artwork, not a photograph of the exact product',
                     button='Search on Amazon', aria=aria)
        for t, d, url, aria in CHAIR_SEARCH)
    out.append(group_html('chairs', 'Chairs and desks', 'Gaming chairs and desks.', chair_cards))
    return '\n'.join(out)


def asset_card(path, name, desc, label, primary=False):
    cls = 'logo-card is-primary' if primary else 'logo-card'
    badge = '<span class="badge">Primary · in use on site</span>' if primary else ''
    return (f'<article class="{cls}">'
            f'<div class="thumb"><img src="{path}" alt="{esc(name)}" loading="lazy"{size_attr(path)}></div>'
            f'<div class="meta">{badge}<h4>{esc(name)}</h4><p>{esc(desc)}</p>'
            f'<a class="btn btn-ghost btn-sm" href="{path}" download>{esc(label)}</a></div></article>')


def index_body():
    filters = ''.join(
        f'<button class="chip-btn" type="button" data-filter="{key}" aria-pressed="{"true" if key == "all" else "false"}">{esc(label)}</button>'
        for key, label in FILTERS)
    steps = ''.join(
        f'<article class="step"><span class="num">{n}</span><h3>{esc(t)}</h3><p>{esc(d)}</p></article>'
        for n, t, d in STEPS)
    guide_cards = ''.join(
        f'<a class="guide" href="guides/{slug}.html"><h3>{esc(title)}</h3><p>{esc(summary)}</p></a>'
        for slug, title, summary in GUIDES)
    faq = ''.join(f'<details><summary>{esc(q)}</summary><p>{esc(a)}</p></details>' for q, a in FAQ)
    policy_cards = ''
    for title, body, extra in POLICIES:
        policy_cards += f'<article class="policy"><h3>{esc(title)}</h3><p>{body}</p>'
        if extra:
            policy_cards += f'<p>{esc(extra)}</p>'
        policy_cards += '</article>'
    logo_cards = ''.join(asset_card(f'assets/logos/{f}', n, d, 'Download PNG', p) for f, n, d, p in LOGO_OPTIONS)
    asset_cards = (asset_card('assets/social-preview.jpg', 'Social preview · 1200×630',
                              'Share image shown when the website link is posted on social media.', 'Download JPG')
                   + asset_card('assets/hero-controller.jpg', 'Hero artwork',
                                'Illustrative controller artwork used in the homepage hero.', 'Download JPG'))
    swatches = ''.join(
        f'<div class="swatch"><i style="background:{hx}"></i><div><strong>{esc(name)}</strong>'
        f'<code>{hx}</code><p>{esc(role)}</p></div></div>'
        for name, hx, role in SWATCHES)

    hero = f'''<section class="hero" aria-labelledby="hero-title">
  <div class="wrap hero-grid">
    <div class="hero-copy">
      <p class="eyebrow">The gaming gear discovery studio</p>
      <h1 id="hero-title">Build a setup that feels like yours.</h1>
      <p class="lead">Explore practical guides and carefully organized gaming-gear listings. Start with comfort, compatibility and the way you play—then check the exact model and current details with the seller.</p>
      <div class="cta-row">
        <a class="btn btn-primary" href="#categories">Explore gaming gear <span aria-hidden="true">↗</span></a>
        <a class="btn btn-ghost" href="#guides">Read the buying guides</a>
      </div>
      <ul class="chips">
        <li>Fit-first advice</li>
        <li>Compatibility checks</li>
        <li>No invented prices</li>
      </ul>
      <p class="tagline">Discover • Play • Save</p>
    </div>
    <figure class="hero-art">
      <div class="art-glow" aria-hidden="true"></div>
      <p class="art-title">PROGAMEFINDS / SETUP LAB GEAR GUIDE<strong>YOUR SPACE. YOUR PLAYSTYLE.<br>Make every upgrade count.</strong></p>
      <img src="assets/hero-controller.jpg" alt="Illustrative gaming controller artwork"{size_attr('assets/hero-controller.jpg')}>
      <figcaption>Illustrative artwork · Not product photography</figcaption>
    </figure>
  </div>
  <div class="wrap">
    <div class="notice" role="note">
      <p><strong>Amazon Associates application status must be confirmed by the site owner.</strong> The current site notice records the application as pending. Do not treat ProGameFinds as approved until Associates Central confirms acceptance. <a href="affiliate-disclosure.html">Read the affiliate disclosure</a>.</p>
    </div>
  </div>
</section>'''

    essentials = f'''<section class="section" id="essentials">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Fit • Platform • Budget</p>
      <h2>Start with the essentials</h2>
    </div>
    <div class="steps">{steps}</div>
  </div>
</section>'''

    gear = f'''<section class="section" id="categories">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Explore the gear</p>
      <h2>Find your next upgrade.</h2>
      <p>Browse the existing owner-supplied listing candidates by category. Product names, ASIN-to-product matches, seller, model revision and compatibility still require owner verification against the manufacturer and current retailer listing. We do not display live prices, stock claims, ratings or customer reviews.</p>
    </div>
    <div class="toolbar">
      <div class="filters" role="group" aria-label="Filter by category">{filters}</div>
      <label class="search"><span class="sr-only">Search gear</span><input id="gear-search" type="search" placeholder="Search gear" autocomplete="off"><kbd aria-hidden="true">/</kbd></label>
    </div>
    <p class="status" id="gear-status" role="status" aria-live="polite">Showing all current listings.</p>
    {groups_html()}
  </div>
</section>'''

    guides = f'''<section class="section" id="guides">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Buying guides</p>
      <h2>Gaming gear buying guides</h2>
      <p>Practical, independent checklists to help compare fit, compatibility, features and long-term value. These are buying guides, not claims of hands-on product testing.</p>
    </div>
    <div class="guides">{guide_cards}</div>
  </div>
</section>'''

    brand = f'''<section class="section" id="logo">
  <div class="wrap">
    <div class="section-head">
      <p class="eyebrow">Brand kit</p>
      <h2>Our logo and every logo option</h2>
      <p>Official ProGameFinds logo files, ready to download. Use the primary logo wherever possible.</p>
    </div>
    <div class="logo-hero">
      <figure class="logo-stage"><span class="logo-tile"><img src="assets/logos/logo-primary-stacked.png" alt="ProGameFinds primary logo, stacked PGF crown lockup"{size_attr('assets/logos/logo-primary-stacked.png')}></span></figure>
      <div class="logo-note">
        <p class="eyebrow">Primary logo</p>
        <h3>Stacked PGF crown lockup</h3>
        <p>This is the logo used across the website header and footer. Every other option below is a supporting variant for banners, avatars and small spaces.</p>
      </div>
    </div>
    <div class="logo-grid">{logo_cards}{asset_cards}</div>
    <div class="brand-meta">
      <div>
        <h3>Colour palette</h3>
        <p class="muted">Colours taken from the logo artwork.</p>
        <div class="swatches">{swatches}</div>
      </div>
      <div class="type-sample">
        <h3>Typography</h3>
        <p><strong>Headings:</strong> Exo 2, bold</p>
        <p><strong>Body text:</strong> Inter, regular and medium</p>
      </div>
    </div>
  </div>
</section>'''

    faq_section = f'''<section class="section" id="faq">
  <div class="wrap"><div class="faq">
    <h2>Questions</h2>
    {faq}
  </div></div>
</section>'''

    policies = f'''<section class="section" id="policies">
  <div class="wrap">
    <div class="section-head">
      <h2>Policies</h2>
      <p>How this site handles affiliate links, contact messages, and product details.</p>
    </div>
    <div class="policy-grid">{policy_cards}</div>
    <p class="policy-date">Last updated November 19, 2026.</p>
  </div>
</section>'''

    contact = '''<section class="section" id="contact">
  <div class="wrap contact-grid">
    <div class="contact-card">
      <p class="eyebrow">Contact</p>
      <h2>Send us a message</h2>
      <p>Questions about a product, a link, or this site? Email our support inbox and we will reply when available.</p>
      <p><a class="btn btn-primary" href="mailto:support@progamefinds.online">Email ProGameFinds support</a></p>
      <p class="form-note">Direct email opens your device email app. The on-page form is not enabled yet.</p>
      <ul>
        <li>Your details are used only to reply to your message.</li>
        <li>Prices and stock are shown on the Amazon product page.</li>
      </ul>
    </div>
    <div class="contact-card">
      <form class="contact-form" aria-describedby="form-note">
        <fieldset disabled>
          <label>Full name (required)<input name="name" type="text" autocomplete="name"></label>
          <label>Email address (required)<input name="email" type="email" autocomplete="email"></label>
          <label>Topic
            <select name="topic">
              <option>Choose a topic</option>
              <option>Product question</option>
              <option>Affiliate or partnership</option>
              <option>Website issue</option>
              <option>Other</option>
            </select>
          </label>
          <label>Message (required)<textarea name="message" minlength="10"></textarea><small>At least 10 characters.</small></label>
          <label class="hp" aria-hidden="true">Leave this field empty<input name="website" type="text" tabindex="-1" autocomplete="off"></label>
          <button class="btn btn-ghost" type="button">Contact form not active</button>
        </fieldset>
      </form>
      <p class="form-note" id="form-note">On-page form submissions are not active. For enquiries, use the direct support email link shown beside this notice. No contact data is sent through this form.</p>
      <p class="form-note">Enable JavaScript to send this form.</p>
    </div>
  </div>
</section>'''

    return '\n'.join([hero, essentials, gear, guides, brand, faq_section, policies, contact])


def md_page(path, text, active='', desc=None):
    lines = text.strip('\n').split('\n')
    title = re.sub(r'^#\s+', '', lines[0]).strip()
    rest = '\n'.join(lines[1:])
    rel = '../' if path.startswith('guides/') else ''
    if desc is None:
        first = next((l for l in rest.split('\n') if l.strip() and not l.lstrip().startswith('#')), title)
        desc = plain(first)[:158]
    crumbs = '<p class="crumbs"><a href="../index.html#guides">&larr; All buying guides</a></p>\n' if rel else ''
    body = '<article class="prose wrap">\n' + crumbs + '<h1>' + esc(title) + '</h1>\n' + md(rest, rel) + '\n</article>'
    return page(title + ' | ProGameFinds', desc, path, body, active)


def write(rel_path, content):
    full = os.path.join(OUT, rel_path)
    os.makedirs(os.path.dirname(full), exist_ok=True)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(content)


def read_content(rel_path):
    with open(os.path.join(SRC, 'content', rel_path), encoding='utf-8') as f:
        return f.read()


def main():
    if os.path.exists(OUT):
        shutil.rmtree(OUT)
    os.makedirs(OUT)
    shutil.copytree(os.path.join(SRC, 'assets'), os.path.join(OUT, 'assets'))
    for name in ('favicon.ico', 'apple-touch-icon.png'):
        shutil.copy(os.path.join(SRC, name), os.path.join(OUT, name))
    write('index.html', page('ProGameFinds | Gaming Gear Guides, Picks & Setup Ideas', DESC_HOME,
                             'index.html', index_body(), 'gear'))
    for slug, active in [('about', 'about'), ('affiliate-disclosure', ''), ('privacy', ''), ('terms', '')]:
        path = slug + '.html'
        write(path, md_page(path, read_content(slug + '.md'), active))
    for slug, _title, summary in GUIDES:
        path = f'guides/{slug}.html'
        write(path, md_page(path, read_content(f'guides/{slug}.md'), 'guides', desc=summary))
    write('README.txt', README)
    print('built', OUT)


if __name__ == '__main__':
    main()
