import os
import shutil
import sys

sys.path.insert(0, '/home/claude/site-src')
import build as b  # noqa: E402

PARTIAL_README = """ProGameFinds - new homepage, logo and colour theme

This package contains the new homepage (index.html) and the shared theme files.
Subpages (about, affiliate disclosure, privacy, terms and the buying guides) are NOT included here.
Keep your existing versions; they will keep working because the new theme uses new file names.

Upload or replace:
- index.html
- assets/progamefinds-theme.css and assets/progamefinds-app.js
- assets/logos/, assets/icons/, assets/social-preview.jpg, assets/hero-controller.jpg
- favicon.ico and apple-touch-icon.png

Keep your existing files that are not listed here, including assets/products/ (product images),
CNAME, sitemap.xml and robots.txt.

Affiliate links, the tracking ID (progamefinds-20) and the disclosure text are unchanged.
"""

def main():
    if os.path.exists(b.OUT):
        shutil.rmtree(b.OUT)
    os.makedirs(b.OUT)
    shutil.copytree(os.path.join(b.SRC, 'assets'), os.path.join(b.OUT, 'assets'),
                    ignore=shutil.ignore_patterns('products'))
    for name in ('favicon.ico', 'apple-touch-icon.png'):
        shutil.copy(os.path.join(b.SRC, name), os.path.join(b.OUT, name))
    b.write('index.html', b.page('ProGameFinds | Gaming Gear Guides, Picks & Setup Ideas', b.DESC_HOME,
                                 'index.html', b.index_body(), 'gear'))
    b.write('README.txt', PARTIAL_README)
    print('index built')

main()
