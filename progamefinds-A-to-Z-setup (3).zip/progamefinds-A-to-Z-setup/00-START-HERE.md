# ProGameFinds: A to Z setup

Ye package mein progamefinds.online ke naye design ki saari files hain. Pehle ye file padh lein.

## Folder mein kya hai

- `site/`: website ki final files. Inhe GitHub repo ke root mein upload karna hai.
- `subpages/`: about, affiliate disclosure, privacy, terms aur guides ke templates.
- `docs/BRAND-GUIDE.md`: logo rules, colours aur fonts.
- `docs/CONTENT-INVENTORY.md`: har page aur har Amazon link (ASIN aur tag ke saath).
- `docs/LAUNCH-CHECKLIST.md`: publish se pehle aur baad ki checklist.
- `source/`: generator scripts. Sirf developer ke liye, optional.

## Status

- Homepage (`site/index.html`): complete. Naya logo, theme, logo kit aur saara content.
- Theme files, logos, icons, favicon, social preview aur hero artwork: complete.
- `sitemap.xml` aur `robots.txt`: complete.
- Subpages (about, affiliate disclosure, privacy, terms aur 10 guides): PENDING. Inka content mere paas nahi aaya, isliye ye package mein nahi hain.

## Step 1: Homepage upload (GitHub)

1. Design branch kholein (PR #2 wali).
2. "Add file" → "Upload files" par click karein.
3. `site/` folder ke andar ki sab files aur folders drag karein: `index.html`, `favicon.ico`, `apple-touch-icon.png`, `robots.txt`, `sitemap.xml` aur `assets/`.
4. GitHub upload kisi existing file ko delete nahi karta. Wo sirf add ya replace karta hai, isliye `assets/products/` waise hi rahega.
5. Commit karein, preview check karein, phir PR merge karein.

Netlify, Vercel ya Cloudflare Pages use kar rahe hain to unke dashboard mein `site/` ki files drag-and-drop karein.

## Step 2: Subpages (Associates ke liye bhi zaroori)

**Option A: aap khud convert karein**
1. `subpages/subpage-template.html` ko Notepad ya VS Code mein kholein.
2. `STEP 1` wale comment ke neeche ki heading aur paragraph hata kar apne purane page ka content paste karein. Wording, links aur disclosure text bilkul same rakhein.
3. Title aur `canonical` URL us page ke hisaab se badlein.
4. File ka naam rakhein: `about.html`, `affiliate-disclosure.html`, `privacy.html`, `terms.html`. Ye `site/` ke root mein upload hongi.
5. Guides ke liye `subpages/guide-template.html` use karein. Har guide ko uske naam se save karein (jaise `choosing-a-gaming-mouse.html`) aur `guides/` folder mein upload karein. Saare 10 guide ke naam `docs/CONTENT-INVENTORY.md` mein hain.

**Option B: mujhe bhejein**
Design branch ka ZIP download karein (Code → Download ZIP) ya subpage files chat mein upload karein. Main same content aur same theme mein poori site ka naya ZIP bana dunga.

## Step 3: Live check

`docs/LAUNCH-CHECKLIST.md` ke saare points check karein.

## Zaroori baatein

- `CNAME` file (agar custom domain ke liye hai) repo mein waise hi rehne dein.
- Ye homepage purane PR wale monogram ko replace karega, kyunki ab aapka asli logo use hota hai.
- Associates ki deadline 26 Nov 2026 hai. Declared site ka live aur bina login ke khulna zaroori hai.
- Product images `assets/products/` se aati hain. Ye folder aapki repo mein hi hai, is package mein nahi.
