(() => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('site-nav');
  if (toggle && nav) {
    const setOpen = (open) => {
      nav.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
      toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    };
    toggle.addEventListener('click', () => setOpen(!nav.classList.contains('open')));
    nav.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => setOpen(false)));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') setOpen(false); });
  }

  const input = document.getElementById('gear-search');
  const status = document.getElementById('gear-status');
  const chips = Array.from(document.querySelectorAll('.chip-btn'));
  const products = Array.from(document.querySelectorAll('.product[data-cat]'));
  const groups = Array.from(document.querySelectorAll('.group'));
  if (!input || !status || !products.length) return;

  let category = 'all';
  const apply = () => {
    const q = input.value.trim().toLowerCase();
    let shown = 0;
    products.forEach((p) => {
      const matchCat = category === 'all' || p.dataset.cat === category;
      const matchText = !q || (p.dataset.search + ' ' + p.textContent).toLowerCase().includes(q);
      p.hidden = !(matchCat && matchText);
      if (!p.hidden) shown += 1;
    });
    groups.forEach((g) => { g.hidden = !g.querySelector('.product:not([hidden])'); });
    if (shown === 0) status.textContent = 'No listings match your search. Try another keyword.';
    else if (category === 'all' && !q) status.textContent = 'Showing all current listings.';
    else status.textContent = 'Showing ' + shown + ' matching listing' + (shown === 1 ? '' : 's') + '.';
  };
  chips.forEach((chip) => chip.addEventListener('click', () => {
    category = chip.dataset.filter;
    chips.forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
    apply();
  }));
  input.addEventListener('input', apply);
  document.addEventListener('keydown', (e) => {
    const tag = (document.activeElement && document.activeElement.tagName) || '';
    if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(tag)) { e.preventDefault(); input.focus(); }
  });
})();
