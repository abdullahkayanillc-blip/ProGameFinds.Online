# Content inventory

Which page holds what, and how every Amazon link must look (tag=progamefinds-20).

## Pages

| Page | File | Status |
| --- | --- | --- |
| Homepage | index.html | Ready (new theme) |
| About | about.html | Needs your existing file |
| Affiliate disclosure | affiliate-disclosure.html | Needs your existing file |
| Privacy | privacy.html | Needs your existing file |
| Terms | terms.html | Needs your existing file |
| Guide: How to choose a gaming mouse | guides/choosing-a-gaming-mouse.html | Needs your existing file |
| Guide: Gaming keyboard layouts and switches | guides/gaming-keyboard-layouts-and-switches.html | Needs your existing file |
| Guide: How to choose a gaming headset | guides/choosing-a-gaming-headset.html | Needs your existing file |
| Guide: Controller compatibility checklist | guides/controller-compatibility-checklist.html | Needs your existing file |
| Guide: Gaming desk sizing guide | guides/gaming-desk-sizing-guide.html | Needs your existing file |
| Guide: Gaming chair fit and ergonomics | guides/gaming-chair-fit-and-ergonomics.html | Needs your existing file |
| Guide: Gaming room lighting guide | guides/gaming-room-lighting.html | Needs your existing file |
| Guide: Build a balanced gaming setup | guides/building-a-balanced-gaming-setup.html | Needs your existing file |
| Guide: Wired vs wireless gaming gear | guides/wired-vs-wireless-gaming-gear.html | Needs your existing file |
| Guide: How to evaluate a product listing | guides/how-to-check-an-online-product-listing.html | Needs your existing file |

## Amazon links (every link must carry tag=progamefinds-20)

| # | Section | Label | Item | ASIN | Link |
| --- | --- | --- | --- | --- | --- |
| 1 | Mice | Pick 01.1 | Logitech G305 LIGHTSPEED | B07CMS5Q6P | https://www.amazon.com/dp/B07CMS5Q6P?tag=progamefinds-20 |
| 2 | Mice | Pick 01.2 | Logitech G502 HERO | B07GBZ4Q68 | https://www.amazon.com/dp/B07GBZ4Q68?tag=progamefinds-20 |
| 3 | Mice | Alternative | Logitech G502 X Plus Wireless | B092CB69Q4 | https://www.amazon.com/dp/B092CB69Q4?tag=progamefinds-20 |
| 4 | Mice | Alternative | Logitech G502 Lightspeed (HERO 25K) | B07L4BM851 | https://www.amazon.com/dp/B07L4BM851?tag=progamefinds-20 |
| 5 | Headsets | Pick 02.1 | HyperX Cloud III | B0C3BSZ56D | https://www.amazon.com/dp/B0C3BSZ56D?tag=progamefinds-20 |
| 6 | Headsets | Pick 02.2 | Razer BlackShark V2 X | B086PKMZ21 | https://www.amazon.com/dp/B086PKMZ21?tag=progamefinds-20 |
| 7 | Headsets | Alternative | HyperX Cloud III S Wireless | B0F6NZWPTC | https://www.amazon.com/dp/B0F6NZWPTC?tag=progamefinds-20 |
| 8 | Headsets | Alternative | HyperX Cloud II | B00SAYCXWG | https://www.amazon.com/dp/B00SAYCXWG?tag=progamefinds-20 |
| 9 | Headsets | Alternative | HyperX Cloud III (second listing) | B0C3BV19Q3 | https://www.amazon.com/dp/B0C3BV19Q3?tag=progamefinds-20 |
| 10 | Keyboards | Pick 03.1 | Logitech G213 Prodigy | B07QGHK6Q8 | https://www.amazon.com/dp/B07QGHK6Q8?tag=progamefinds-20 |
| 11 | Keyboards | Pick 03.2 | SteelSeries Apex 3 TKL RGB | B09FTNMT84 | https://www.amazon.com/dp/B09FTNMT84?tag=progamefinds-20 |
| 12 | Controllers | Pick 04.1 | GameSir G7 Pro | B0FD41XC3P | https://www.amazon.com/dp/B0FD41XC3P?tag=progamefinds-20 |
| 13 | Controllers | Pick 04.2 | GameSir G7 SE | B0C7GW9F88 | https://www.amazon.com/dp/B0C7GW9F88?tag=progamefinds-20 |
| 14 | Controllers | Alternative | GameSir G7 SE (licensed edition) | B0CT3BXRLS | https://www.amazon.com/dp/B0CT3BXRLS?tag=progamefinds-20 |
| 15 | Controllers | Alternative | GameSir Nova Lite 2 Wireless | B0F3D25PD3 | https://www.amazon.com/dp/B0F3D25PD3?tag=progamefinds-20 |
| 16 | Setup and room | Pick 05.1 | Govee RGBIC LED Strip | B0991Q94KP | https://www.amazon.com/dp/B0991Q94KP?tag=progamefinds-20 |
| 17 | Setup and room | Pick 05.2 | KSIPZE 100ft RGB Strip | B09V366BDY | https://www.amazon.com/dp/B09V366BDY?tag=progamefinds-20 |
| 18 | Setup and room | Alternative | DAYBETTER LED Strip 32.8 ft | B08D99TWQJ | https://www.amazon.com/dp/B08D99TWQJ?tag=progamefinds-20 |
| 19 | Setup and room | Alternative | HBOWMDJIA LED Lights 200 ft | B0DFYBYPZM | https://www.amazon.com/dp/B0DFYBYPZM?tag=progamefinds-20 |
| 20 | Setup and room | Alternative | Leeleberd LED Lights 100 ft | B0C2MHG632 | https://www.amazon.com/dp/B0C2MHG632?tag=progamefinds-20 |
| 21 | Chairs and desks | Category search | Gaming chairs | - | https://www.amazon.com/s?k=gaming+chair&tag=progamefinds-20 |
| 22 | Chairs and desks | Category search | Gaming desks | - | https://www.amazon.com/s?k=gaming+desk&tag=progamefinds-20 |

Total tagged links on the homepage: 22

## Other content on the homepage

- Hero, essentials (3 steps), gear filters and search, guides list (10), brand kit, FAQ (4 questions), policies (4 blocks, last updated November 19, 2026), contact section and footer.
- Contact email: support@progamefinds.online (mailto link).
- Footer notice: Amazon Associates application pending, ProGameFinds is not yet approved. Keep it until Amazon confirms approval.
