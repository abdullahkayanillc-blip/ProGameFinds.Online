# Launch checklist

## Upload se pehle
- [ ] `site/` ki sab files repo root mein upload ho gayi hain
- [ ] `assets/products/` repo mein hai aur product images dikh rahi hain
- [ ] Subpages (about, affiliate disclosure, privacy, terms, 10 guides) upload ho gaye hain
- [ ] Preview link desktop aur phone dono par khula

## Publish ke baad (https://progamefinds.online)
- [ ] Incognito window mein bina login ke khulta hai, HTTPS lock dikhta hai
- [ ] Header mein naya logo dikhta hai, browser tab mein favicon dikhta hai
- [ ] Navigation links khulte hain: About, Questions, Contact, Affiliate disclosure, Privacy, Terms, aur guides
- [ ] Ek product ka "View on Amazon" button Amazon khol raha hai, aur link mein `tag=progamefinds-20` hai
- [ ] Category filters aur search kaam kar rahe hain
- [ ] Contact button (support@progamefinds.online) email app kholta hai
- [ ] Mobile par hamburger menu khulta hai
- [ ] https://progamefinds.online/sitemap.xml khulta hai
- [ ] Social preview check: link ko Facebook Sharing Debugger ya kisi social preview tool mein dekhein

## Amazon Associates
- [ ] Declared site URL live hai aur bina login ke khulta hai
- [ ] Affiliate disclosure page live hai aur homepage par dikhta hai
- [ ] Associates Central mein status recheck kiya (deadline 26 Nov 2026)

Optional: Google Search Console mein sitemap submit karein.
