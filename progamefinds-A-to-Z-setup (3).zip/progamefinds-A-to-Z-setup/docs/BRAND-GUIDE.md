# ProGameFinds Brand Guide

## Logo files

| Logo | File | Use it for |
| --- | --- | --- |
| Primary logo (stacked PGF crown lockup) | assets/logos/logo-primary-stacked.png | Website header and footer, main brand presentations |
| Full logo (with controller and tagline) | assets/logos/logo-full-with-controller.png | Large placements, posters, presentations |
| Horizontal logo | assets/logos/logo-horizontal-banner.png | Wide headers and banners |
| Wordmark | assets/logos/logo-wordmark.png | Text-only spaces and small footers |
| App icon (rounded neon) | assets/logos/icon-app-rounded.png | App icons, social avatars |
| Round badge (cyan ring) | assets/logos/icon-round-cyan.png | Profile pictures |
| Round badge (violet ring) | assets/logos/icon-round-violet.png | Profile pictures (alternate) |
| Crest badge | assets/logos/icon-crest.png | Stickers and small badges |
| Favicon | favicon.ico, apple-touch-icon.png, assets/icons/ | Browser tab and home screen icons |
| Social preview | assets/social-preview.jpg (1200 x 630) | Link preview when the site is shared |
| Hero artwork | assets/hero-controller.jpg | Homepage hero (illustrative, not product photography) |

## Logo rules

- Use the files as supplied. Do not stretch, rotate, recolour, or add shadows or outlines.
- The logos are designed for dark backgrounds. On a light background, place the logo on a dark panel instead.
- Keep clear space around the logo. Do not place text or graphics over it.
- For very small sizes (below about 32 px), use the app icon or favicon instead of the full lockup.

## Colours

| Name | Hex | Use |
| --- | --- | --- |
| Midnight | #000007 | Page background |
| Deep navy | #00103B | Panels and cards |
| Royal blue | #00287C | Deep accents |
| Indigo | #412B9B | Gradient mid-tone |
| Neon violet | #8A3FFC | Primary buttons and highlights |
| Neon cyan | #46D7FF | Links and accents |
| Steel silver | #758EBD | Secondary text and dividers |
| Ice silver | #C7E2ED | Headings and light text |

Website UI colours: body text #EEF5FB, muted text #9AAECD, and the primary button gradient #2A5CFF → #412B9B → #8A3FFC (120 degrees).

## Typography

- Headings: Exo 2 (weights 600, 700, 800), from Google Fonts.
- Body text: Inter (weights 400, 500, 600), from Google Fonts.

## Brand text

- Tagline: Discover • Play • Save
- Homepage headline: Build a setup that feels like yours.
- Social handle: @ProGameFinds
